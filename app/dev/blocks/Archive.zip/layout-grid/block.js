import "./scss/block.scss";

import {
    BlockContextProvider, InnerBlocks,
    InspectorControls,
    useBlockProps,
    useInnerBlocksProps,
} from "@wordpress/block-editor"
import {registerBlockType,} from "@wordpress/blocks"
import metadata from "./block.json"
import {LAYOUT_ATTRIBUTES, LayoutControls} from "Components/Layout"
import {BACKGROUND_ATTRIBUTES, BackgroundControls, BackgroundElement} from "Components/Background"
import {Style, STYLE_ATTRIBUTES, styleClasses} from "Components/Style"
import {LOOP_ATTRIBUTES, LoopControls} from "Components/Loop"
import {GRID_ATTRIBUTES, GridControls, gridProps} from "Components/Grid"
import {
    PanelBody,
    TabPanel,
} from "@wordpress/components";
import {useInstanceId} from "@wordpress/compose";
import React, {useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState} from "react";
import {cleanObject, useUniqueId} from "Includes/helper";
import {isEqual} from "lodash";


function classNames(attributes = {}) {

    return [
        'wpbs-layout-grid',
        !!attributes?.['wpbs-grid']?.masonry ? '--masonry' : null,
        'w-full flex relative',
        !!attributes['wpbs-query']?.pagination ? 'wpbs-layout-grid--pagination' : null,
        'wpbs-container',
        attributes?.uniqueId,
    ].filter(x => x).join(' ');
}

registerBlockType(metadata.name, {
    apiVersion: 3,
    attributes: {
        ...metadata.attributes,
        ...LAYOUT_ATTRIBUTES,
        ...BACKGROUND_ATTRIBUTES,
        ...STYLE_ATTRIBUTES,
        ...LOOP_ATTRIBUTES,
        ...GRID_ATTRIBUTES,

    },
    edit: ({attributes, setAttributes, clientId}) => {

        //const uniqueId = useInstanceId(registerBlockType, 'wpbs-layout-grid');

        const uniqueId = useUniqueId(attributes, setAttributes, clientId);

        useEffect(() => {

            const newSettings = cleanObject({
                uniqueId: uniqueId,
                loop: !!(attributes?.className ?? '').includes('is-style-loop'),
                button: {
                    label: attributes?.['wpbs-query']?.pagination_label,
                    enabled: !!attributes?.['wpbs-query']?.posts_per_page,
                }
            });

            if (!isEqual(attributes['wpbs-grid-settings'], newSettings)) {
                setAttributes({
                    'wpbs-grid-settings': newSettings
                });
            }


        }, [attributes?.['wpbs-query'], uniqueId])

        const cssProps = useMemo(() => {
            return gridProps(attributes);
        }, [attributes]);

        const tabOptions = <GridControls attributes={attributes} setAttributes={setAttributes}/>;

        const tabLoop = <LoopControls attributes={attributes} setAttributes={setAttributes}/>;

        const tabs = {
            options: tabOptions,
            loop: tabLoop,
        }

        const blockProps = useBlockProps({
            className: classNames(attributes)
        });

        const innerBlocksProps = useInnerBlocksProps(blockProps, {
            allowedBlocks: [
                "wpbs/layout-element",
                "wpbs/layout-grid-container",
                "wpbs/pagination-button",
                "core/query-pagination",
            ]
        });

        return (
            <>
                <InspectorControls group="styles">

                    <PanelBody>

                        <TabPanel
                            className="wpbs-editor-tabs"
                            activeClass="active"
                            orientation="horizontal"
                            initialTabName="options"
                            tabs={[
                                {
                                    name: 'options',
                                    title: 'Options',
                                    className: 'tab-options',
                                },
                                {
                                    name: 'loop',
                                    title: 'Loop',
                                    className: 'tab-loop'
                                },
                            ]}>
                            {
                                (tab) => (<>{tabs[tab.name]}</>)
                            }
                        </TabPanel>

                    </PanelBody>


                </InspectorControls>
                <LayoutControls attributes={attributes} setAttributes={setAttributes}/>
                <BackgroundControls attributes={attributes} setAttributes={setAttributes}/>
                <Style attributes={attributes} setAttributes={setAttributes} uniqueId={uniqueId}
                       deps={['wpbs-grid']} selector={'wpbs-layout-grid'}
                       props={cssProps}
                />

                <div {...blockProps}>
                    {innerBlocksProps.children}
                    <BackgroundElement attributes={attributes} editor={true}/>
                </div>

            </>
        )
    },
    save: (props) => {

        const blockProps = useBlockProps.save({
            className: classNames(props.attributes),
            'data-wp-interactive': 'wpbs/layout-grid',
            'data-wp-init': 'actions.init',
            ...(props.attributes?.['wpbs-props'] ?? {})
        });

        return (
            <div {...blockProps}>
                <InnerBlocks.Content/>
                <BackgroundElement attributes={props.attributes} editor={false}/>
            </div>
        );
    }
})


