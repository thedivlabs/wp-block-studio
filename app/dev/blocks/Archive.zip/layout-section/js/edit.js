import {
    useBlockProps,
    InspectorControls,
    useInnerBlocksProps,
} from "@wordpress/block-editor"
import {registerBlockType} from "@wordpress/blocks"
import metadata from "../block.json"
import {LayoutClasses, LayoutSettings} from "Components/Layout"
import {Background, BackgroundSettings} from "Components/Background";
import {ElementTagSettings, ElementTag, ElementTagAttributes} from "Components/ElementTag";
import {
    __experimentalGrid as Grid,
} from "@wordpress/components";
import {useInstanceId} from "@wordpress/compose";
import React, {useEffect} from "react";
import {Style, styleAttributesFull} from "Components/Style.js";


function sectionClassNames(attributes = {}) {

    return [
        'wpbs-layout-section wpbs-layout-container wpbs-has-container w-full flex relative',
        attributes.uniqueId,
        LayoutClasses(attributes)
    ].filter(x => x).join(' ');
}

function containerClassNames() {

    return [
        'container relative z-20',
    ].filter(x => x).join(' ');

}

registerBlockType(metadata.name, {
    apiVersion: 3,
    attributes: {
        ...metadata.attributes,
        ...styleAttributesFull,
        ...ElementTagAttributes
    },
    edit: ({attributes, setAttributes, clientId}) => {

        const uniqueId = useInstanceId(registerBlockType, 'wpbs-layout-section');

        useEffect(() => {
            setAttributes({uniqueId: uniqueId});
        }, []);

        const blockProps = useBlockProps({
            className: [sectionClassNames(attributes), 'min-h-8'].join(' '),
        });

        const ElementTagName = ElementTag(attributes);

        const innerBlocksProps = useInnerBlocksProps({
            className: containerClassNames()
        });

        return (
            <>
                <InspectorControls group="styles">
                    <BackgroundSettings attributes={attributes || {}}
                                        pushSettings={setAttributes}></BackgroundSettings>
                </InspectorControls>
                <InspectorControls group="advanced">
                    <Grid columns={1} columnGap={15} rowGap={20} style={{paddingTop: '20px'}}>
                        <ElementTagSettings attributes={attributes} callback={setAttributes}></ElementTagSettings>
                    </Grid>
                </InspectorControls>
                <LayoutSettings attributes={attributes} setAttributes={setAttributes} />

                <ElementTagName {...blockProps}
                                data-wp-interactive='wpbs-layout-section'
                >
                    <div {...innerBlocksProps}/>

                    <Background attributes={attributes} editor={true}/>
                    <Style attributes={attributes} setAttributes={setAttributes} uniqueId={uniqueId} selector={'wpbs-layout-section'} />
                </ElementTagName>
            </>
        )
    },
    save: (props) => {


        const blockProps = useBlockProps.save({
            className: sectionClassNames(props.attributes),
        });

        const ElementTagName = ElementTag(props.attributes);

        const innerBlocksProps = useInnerBlocksProps.save({
            className: containerClassNames()
        });

        return (
            <ElementTagName {...blockProps}
            >
                <div {...innerBlocksProps}/>

                <Background attributes={props.attributes} editor={false}/>
            </ElementTagName>
        );
    }
})


